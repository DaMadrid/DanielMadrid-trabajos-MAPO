﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _201829_practica2
{
    interface ITexto
    {
       void usarTexto(string entrada);
    }
}
