﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _180206_actividad1
{
    public interface IObserver
    {
        void Update(float temp,float pres, float hum);
    }
}
